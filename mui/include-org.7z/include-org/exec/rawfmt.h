#if defined(__MORPHOS__)
#include_next <exec/rawfmt.h>
#elif !defined(EXEC_RAWFMT_H)
#define EXEC_RAWFMT_H
#define RAWFMTFUNC_STRING  0
#endif

